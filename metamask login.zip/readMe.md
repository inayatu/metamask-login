# Login with Metamask

Instead of remembing username and password, just login with MetaMask

## Installation

```bash
npm insall
```
